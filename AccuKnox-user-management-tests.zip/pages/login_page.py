
from playwright.sync_api import Page, expect

class LoginPage:
    URL = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login"

    def __init__(self, page: Page):
        self.page = page
        self.username = page.locator("input[name='username']")
        self.password = page.locator("input[name='password']")
        self.login_btn = page.locator("button[type='submit']")

    def navigate(self):
        self.page.goto(self.URL)
        self.page.wait_for_selector("input[name='username']", timeout=5000)

    def login(self, username: str, password: str):
        self.username.fill(username)
        self.password.fill(password)
        self.login_btn.click()
        # wait for admin menu to be visible as an indicator of successful login
        self.page.wait_for_selector("text=Admin", timeout=10000)
