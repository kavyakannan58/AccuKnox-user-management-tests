
from playwright.sync_api import Page, expect

class AdminPage:
    def __init__(self, page: Page):
        self.page = page
        # navigation
        self.admin_menu = page.get_by_role("link", name="Admin")
        self.add_btn = page.get_by_role("button", name="Add")
        # add/edit form fields - placeholders used where possible
        self.employee_name_input = page.locator("input[placeholder='Type for hints...']")
        self.username_field = page.locator("input[placeholder='Username']")
        self.status_dropdown = page.locator("div[role='listbox']").first
        self.password_field = page.locator("input[type='password']").nth(0)
        self.confirm_password_field = page.locator("input[type='password']").nth(1)
        self.save_btn = page.get_by_role("button", name="Save")
        # search
        self.search_username = page.locator("input[placeholder='Username']")
        self.search_btn = page.get_by_role("button", name="Search")
        # delete/edit
        self.first_row_checkbox = page.locator("div.oxd-table-card input[type='checkbox']").first
        self.delete_selected = page.get_by_role("button", name="Delete Selected")
        self.confirm_delete = page.get_by_role("button", name="Yes, Delete")

    def open_admin_module(self):
        self.admin_menu.click()
        self.page.wait_for_selector("button:has-text('Add')", timeout=5000)

    def add_user(self, username: str, password: str, emp_name: str = "Linda Anderson"):
        self.add_btn.click()
        # select user role ESS (click text ensures visible selection)
        self.page.get_by_text("ESS").click()
        self.employee_name_input.fill(emp_name)
        # wait for suggestion and pick first suggestion
        self.page.wait_for_selector("div[role='option']", timeout=5000)
        self.page.locator("div[role='option']").first.click()
        self.username_field.fill(username)
        # select status - choose Enabled
        self.page.get_by_text("Enabled").click()
        self.password_field.fill(password)
        self.confirm_password_field.fill(password)
        self.save_btn.click()
        # wait for user table to show username
        self.page.wait_for_selector(f"text={username}", timeout=10000)

    def search_user(self, username: str):
        self.search_username.fill(username)
        self.search_btn.click()
        # wait for results update
        self.page.wait_for_selector("div.oxd-table-card", timeout=5000)

    def edit_user_set_role_admin(self, username: str):
        self.search_user(username)
        # click edit (pencil) on first result - using button with title attribute if available
        # fallback to first pencil icon
        try:
            self.page.locator("button[title='Edit']").first.click()
        except Exception:
            self.page.locator("i.bi-pencil-fill").first.click()
        # on edit page, select Admin role (text click)
        self.page.get_by_text("Admin").click()
        self.save_btn.click()
        self.page.wait_for_selector("text=Successfully Updated", timeout=5000)

    def delete_user(self, username: str):
        self.search_user(username)
        # select first checkbox and delete
        self.first_row_checkbox.check()
        self.delete_selected.click()
        self.confirm_delete.click()
        # wait for deletion result
        self.page.wait_for_selector("text=No Records Found", timeout=10000)
