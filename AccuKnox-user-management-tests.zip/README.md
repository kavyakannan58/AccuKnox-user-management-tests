
# AccuKnox User Management Automation – OrangeHRM (Python + pytest)

## 🎯 Objective
Automate the User Management workflow on the OrangeHRM demo site using Playwright (Python).

## ⚙️ Project Setup Steps

1. Install Python 3.10+
   - Check: `python --version`

2. Clone the Repository
   ```bash
   git clone https://github.com/<your-username>/AccuKnox-user-management-tests.git
   cd AccuKnox-user-management-tests
   ```

3. Create Virtual Environment
   ```bash
   python -m venv venv
   venv\Scripts\activate      # Windows
   source venv/bin/activate   # Mac/Linux
   ```

4. Install Dependencies
   ```bash
   pip install -r requirements.txt
   playwright install
   ```

## ▶️ How to Run the Test Cases

1. Run all tests in headed mode (with browser visible):
   ```bash
   pytest --headed -q
   ```

2. Run in headless mode (CI friendly):
   ```bash
   pytest -q
   ```

3. Run a specific test file:
   ```bash
   pytest tests/test_add_user.py --headed -q
   ```

## 🧩 Playwright Version Used
Playwright **v1.48.0** (documented here; use latest if preferred)

## 🗂️ Folder Structure
```
AccuKnox-user-management-tests/
├── pages/
│   ├── login_page.py
│   └── admin_page.py
├── tests/
│   ├── test_add_user.py
│   ├── test_search_user.py
│   ├── test_edit_user.py
│   ├── test_validate_user.py
│   └── test_delete_user.py
├── conftest.py
├── requirements.txt
├── README.md
└── AccuKnox_User_Management_TestCases.xlsx
```

## 🪲 Notes / Known Issues
- Employee name auto-suggest may load slowly — tests include waits to handle suggestion population.
- Demo site can be intermittently slow; increase timeouts if tests fail due to speed.

## 👩‍💻 Author
Dhanalakshmi K
