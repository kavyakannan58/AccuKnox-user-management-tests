
from pages.login_page import LoginPage
from pages.admin_page import AdminPage

def test_delete_user(page):
    login = LoginPage(page)
    admin = AdminPage(page)

    login.navigate()
    login.login('Admin', 'admin123')
    admin.open_admin_module()
    admin.delete_user('testuser_accu')
    # verify deletion by searching and expecting 'No Records Found' text
    admin.search_user('testuser_accu')
    assert page.locator("text=No Records Found").is_visible()
