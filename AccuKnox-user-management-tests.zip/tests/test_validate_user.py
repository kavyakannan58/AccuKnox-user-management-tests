
from pages.login_page import LoginPage
from pages.admin_page import AdminPage

def test_validate_user(page):
    login = LoginPage(page)
    admin = AdminPage(page)

    login.navigate()
    login.login('Admin', 'admin123')
    admin.open_admin_module()
    admin.search_user('testuser_accu')
    # ensure role column shows Admin (after edit)
    assert page.locator("text=Admin").first.is_visible()
