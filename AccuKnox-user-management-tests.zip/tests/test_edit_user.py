
from pages.login_page import LoginPage
from pages.admin_page import AdminPage

def test_edit_user(page):
    login = LoginPage(page)
    admin = AdminPage(page)

    login.navigate()
    login.login('Admin', 'admin123')
    admin.open_admin_module()
    admin.edit_user_set_role_admin('testuser_accu')
    # validate role updated by re-searching and checking 'Admin' text in row
    admin.search_user('testuser_accu')
    assert page.locator("text=Admin").first.is_visible()
