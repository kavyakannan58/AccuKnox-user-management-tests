
from pages.login_page import LoginPage
from pages.admin_page import AdminPage

def test_add_user(page):
    login = LoginPage(page)
    admin = AdminPage(page)

    login.navigate()
    login.login('Admin', 'admin123')
    admin.open_admin_module()
    admin.add_user('testuser_accu', 'Test@1234', 'Linda Anderson')
    # verify user exists in table
    assert page.locator("text=testuser_accu").is_visible()
