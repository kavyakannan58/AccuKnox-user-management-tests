
from pages.login_page import LoginPage
from pages.admin_page import AdminPage

def test_search_user(page):
    login = LoginPage(page)
    admin = AdminPage(page)

    login.navigate()
    login.login('Admin', 'admin123')
    admin.open_admin_module()
    admin.search_user('testuser_accu')
    assert page.locator("text=testuser_accu").is_visible()
